# Montaj To Do

---
- [ ] Test editing on Claude Desktop via mcp server
- [ ] Allow speeding up speech
- [ ] Background removal: convert RVM to CoreML (.mlpackage) and run via coremltools on Apple Neural Engine — would match CapCut speed (Neural Engine >> MPS for this class of model). Do it if faster performance is needed.
- [x] **HDR normalize-on-ingest.** When a clip is added to a project, detect HDR (bt2020/HLG/PQ) and auto-convert to the project's working color space (SDR bt709) using ffmpeg tonemap (Hable). Store the normalized file alongside the original. The compose pipeline should never see mixed HDR/SDR formats — CapCut-style early normalization. Also normalize frame rate and codec to project settings (H.264, project fps). *(Done — Render V2 Plan A)*
- [ ] **`collectAllItems` should pass through all item fields.** Currently cherry-picks a subset — any new field (volume, etc.) must be manually added. Use spread with explicit overrides instead.

- [ ] **Generalize `foreach` beyond `"clips"`.** Today `docs/schemas/workflow.md` pins `foreach: "clips"` — it fans a step out across all project clips. For AI-video workflows we need `foreach: "scenes"`, `foreach: "characters"`, `foreach: "environments"` driven by agent-authored arrays in `project.json`. Small engine extension: make `foreach` reference any named array on the project, not just `clips`.

- [ ] **Cross-`foreach` dependencies in the workflow engine.** AI-video workflows need character refs (from a `foreach: "characters"` fan-out) to be passed as `--ref-image` into the corresponding scene's `kling_generate` (a `foreach: "scenes"` fan-out). The current `needs:` dependency model only expresses "step B runs after step A completes for all items" — not "scene-N in step B uses the output of character-K in step A." Needs a per-item dependency expression (e.g. a templated param that resolves against the scene's own fields: `--ref-image {{scene.characterRefs[].path}}`).


### Nice-to-have before public

- [ ] **GitHub Actions CI** — `.github/workflows/test.yml` that runs `make test` on push. Gives contributors confidence. Basic matrix: Python 3.10, 3.12.
- [ ] **Issue templates** — `.github/ISSUE_TEMPLATE/bug_report.md` and `feature_request.md`. Keeps issues useful.
- [ ] **PyPI publish** — Planned. README currently shows install from source. When ready: `python -m build && twine upload dist/*`, then update README to `pip install montaj`.
above.


## Render V2 -- DONE
- [x] **Plan A: Normalize infrastructure** — `lib/normalize.py` shared module. Enforcement at three points: ingest (`init.py`), AI video (`ai_video.py`), and render pre-pass (`render.js`). All sources converted to H.264, yuv420p, bt709, project resolution/fps, 48 kHz audio before compose.
- [x] **Plan B: Segment-based render pipeline** — replaces monolithic `filter_complex` and chunked path. Timeline split at clip/overlay boundaries (`segment-plan.js`), each segment encoded independently (`encode-segment.js`), joined via ffmpeg concat demuxer (`-c:v copy`), audio mixed in final pass (`mix-audio.js`).
- [x] **Plan C: Doctor + deps** — `montaj doctor` (system dependency checker, exit 0/1), `montaj install ffmpeg` (rebuild with zscale/libzimg for HDR normalization, macOS/Homebrew only), `montaj normalize <file>` CLI command.
- Note: normalize creates `_normalized.mp4` alongside originals (storage trade-off — originals preserved for re-export at different settings).

## DONZO
- [x] Adaptors — external AI API harnesses (Stitch/Veo/ElevenLabs/Runway/Suno). Design contract, CLI interface, credential resolution, server routes.
- [x] Build a landing page for montaj
- [x] Remove unused steps (i.e ffmpeg captions) for final cleanup
- [x] Ripple mode for primary track edits — right-edge drag and cuts on tracks[0] should shift all subsequent clips left to close the gap. Currently lift-style (gap left in place). Ripple is the right default for talking-head primary tracks.
- [x] Add workflows for transparent background/talking head — `floating_head.json` added. UI input differentiation deferred (handled at prompt level for now).
- [x] Timeline cuts should be a timeline-level operation affecting all tracks — `applyCutToTracks` (lift-style, all tracks[0] clips) and `applyCutToItem` (collapse-style, single selected item in any track). Selection-aware dispatch in ReviewView. All pure JSON, no re-encode.
- [x] Add support for multi video tracks — addressed by unified `tracks` array (tracks[0] = primary footage, tracks[1+] = overlays; each inner array is one z-level; items can mix overlay/image/video types)
- [x] No need for final concat. Support individual clips in video track — `concat` replaced by trim-spec architecture; compose.js assembles from tracks[0] clips natively
- [x] Add pure audio support — generate_voiceover (Kling TTS + Gemini fallback), generate_music (Lyria 3 Clip), stem_separation. Audio tracks in project.json with volume, ducking, inPoint/outPoint.
- [x] `save_clip_to_project` was wiping overlay tracks — `project["tracks"] = [tracks0]` replaced with `project["tracks"][0] = tracks0`
- [x] Kling connector POST timeout too short for large ref image payloads — bumped from 30s to 120s
- [x] Render resolution auto-detect was ignoring `settings.resolution` — now respects explicit settings over first-clip probe
- [x] `collectAllItems` was dropping `volume` field from video items — added to the field list
- [x] Compose canvas was hardcoded to yuv420p10le — now probes sources and uses yuv420p for SDR-only projects
- [x] Lossless chunk intermediates were hardcoded to yuv420p10le — now matches canvas format
