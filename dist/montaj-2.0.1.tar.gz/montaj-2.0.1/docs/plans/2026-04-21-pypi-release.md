# PyPI & Brew Release — Remaining Steps

## Done
- [x] `pyproject.toml` — license, classifiers, readme, authors, keywords, package-data
- [x] `MANIFEST.in` — includes steps, workflows, skills, schema, docs in sdist
- [x] `engine/__init__.py` + `project/__init__.py` — missing init files for imported packages
- [x] README updated — new steps, workflows, skills, connectors, AI video, install paths
- [x] Version bumped to `2.0.0` across pyproject.toml, render, mcp, ui package.json
- [x] `~/.pypirc` configured with API token
- [x] `python -m build` succeeds, `twine check` passes
- [x] CHANGELOG.md created
- [x] Docs site updated (steps, agents, cli, connectors, installation, concepts, index)
- [x] Test fixes — 337 tests passing

## PyPI upload
- [ ] Rebuild after version bump: `rm -rf dist/ && python -m build`
- [ ] Upload: `twine upload dist/*`
- [ ] Verify: `pip install montaj==2.0.0` from a clean venv

## Git tag
- [ ] Commit all pending changes (version bump, pyproject, MANIFEST, README, init files)
- [ ] Tag: `git tag v2.0.0`
- [ ] Push: `git push origin main && git push origin v2.0.0`

## Homebrew tap update
- [ ] In the `homebrew-montaj` tap repo, update the formula:
  - `url` → point to the `v2.0.0` tarball: `https://github.com/theSamPadilla/montaj/archive/refs/tags/v2.0.0.tar.gz`
  - `sha256` → compute from the tarball: `curl -sL <url> | shasum -a 256`
  - `version` → `2.0.0`
- [ ] Push the tap repo
- [ ] Verify: `brew update && brew upgrade montaj`

## Known limitation: wheel vs sdist
The wheel (`*.whl`) only contains Python packages — `steps/`, `workflows/`, `skills/`, `schema/` are excluded because they aren't Python packages (skill dirs have dashes, steps are standalone scripts). They ARE included in the sdist (`*.tar.gz`).

**Practical impact:** `pip install montaj` installs the wheel, so the CLI and library work but `montaj run` / `montaj step` won't find step scripts. The full agent experience requires a source install (`pip install -e .` from a clone) or brew.

**Future fix options (pick one for a later release):**
1. Restructure into a `montaj/` top-level package namespace — cleanest but biggest refactor
2. Add a `montaj bootstrap` command that fetches steps/skills/workflows from GitHub into `~/.montaj/`
3. Force sdist-only on PyPI (upload only the `.tar.gz`, not the `.whl`) — simple but slower installs
