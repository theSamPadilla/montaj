# Music structure analysis step (all-in-one / allin1)

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add a new Montaj step `music_structure` that analyzes an audio file and outputs tempo, beat timestamps, downbeat timestamps, and labeled structural segments (intro, verse, chorus, bridge, outro, etc.). Wraps [mir-aidj/all-in-one](https://github.com/mir-aidj/all-in-one) — a PyTorch-based music structure analyzer trained on the Harmonix Set. Heavy ML dependency, opt-in via a new `music_structure` extras group and `montaj install music_structure` subcommand.

**Why this shape — no connector, just a step:**
- Runs entirely locally (PyTorch inference). No vendor API, no credentials, no network calls at runtime (weights download once, then cached).
- Same pattern as existing heavy-ML-dependency steps: `transcribe` (whisper), `stem_separation` (demucs), `remove_bg` (rvm). Not the connector pattern.
- Output is a single JSON blob — one input, one output, fits the step contract cleanly.

**Non-goals:**
- No new project types, no schema changes, no UI changes. This is a raw tool; downstream steps/workflows/agents compose with it.
- No beat-synced cut step, no section-cut step, no tempo-match step. Those are agent-level compositions of this step's output + existing `materialize_cut` / trim specs. Ship the raw analyzer first; bespoke composition comes later if usage justifies it.
- No integration into `lyrics_video` or any other existing workflow. Agents opt in.
- No integration with the existing `stem_separation` output. `allin1` does its own source separation internally. Avoiding cross-step data-passing complexity in v1.
- No streaming / partial results. Step blocks until the full analysis is done, then writes JSON.

**Authoritative references (verify before coding):**
- [mir-aidj/all-in-one README](https://github.com/mir-aidj/all-in-one) — confirm package name on PyPI (`allin1`), current version pin, API surface. The README shows the analyze function returning a typed result; lock on that shape.
- [NATTEN install docs](https://github.com/SHI-Labs/NATTEN) — check whether prebuilt wheels exist for the platform or compilation is required.
- [allin1 on PyPI](https://pypi.org/project/allin1/) — confirm latest version for the lower-bound pin.

**Tech Stack:** Python 3.11+, PyTorch (already present in `rvm`/`demucs` extras), `allin1` SDK, `madmom` (pulled in transitively), NATTEN (pulled in transitively).

---

### Task 1: Add `music_structure` extras group to `pyproject.toml`

**Files:**
- Modify: `pyproject.toml`

**Step 1: Verify the PyPI package name and current version**

Before editing, confirm on [PyPI](https://pypi.org/project/allin1/) that the package is `allin1` and the current stable version number. Pin a reasonable lower bound.

**Step 2: Add the extras group**

```toml
# pyproject.toml — [project.optional-dependencies]
music_structure = [
  "allin1>=1.1.0",   # verify exact floor in Task 1 Step 1
]
```

`allin1` pulls in its own deps (`torch`, `madmom`, `natten`, etc.) — don't list them here, let the upstream package decide. If a version conflict surfaces between `allin1`'s torch pin and `rvm`/`demucs`'s torch pin, deal with it when it happens; most likely they coexist cleanly because torch's ABI is stable within minor versions.

**Platform risk — NATTEN:** NATTEN is the biggest install risk. Per the allin1 README (as of plan draft), macOS "auto-installs" NATTEN — no manual step, no compilation dance. Linux and Windows require manual NATTEN install and compilation frequently fails on mismatched Python/torch/CUDA combinations. This plan is being developed on macOS, so the install path is expected to work; Linux/Windows users will hit more turbulence and the error message in Task 2 Step 2 should point them at the NATTEN docs.

**Before proceeding:** verify current macOS compatibility by glancing at the [allin1 issue tracker](https://github.com/mir-aidj/all-in-one/issues) for recent Apple Silicon reports. If there are active unresolved macOS issues (e.g., weight download broken on arm64, MPS backend incompatibility), flag here and decide whether to proceed or defer the plan. Don't trust-read the README alone.

**Step 3: Verification**

```bash
python3 -c 'import tomllib; print(tomllib.load(open("/Users/Sam/Work/ByCrux/dev/montaj/pyproject.toml", "rb"))["project"]["optional-dependencies"]["music_structure"])'
# Expect: ['allin1>=1.1.0']
```

Do NOT run `pip install` yet — that happens via `montaj install music_structure` (Task 2).

---

### Task 2: Add `montaj install music_structure` subcommand

**Files:**
- Modify: `cli/commands/install.py`

**Context:**
Mirrors the existing `_ensure_demucs` and `_ensure_rvm` helpers. Installs the extras group, then prewarms model weights so the first real analysis run doesn't spend 2+ minutes silently downloading.

**Step 1: Add the sub-subparser**

In `cli/commands/install.py`, inside the `sub.add_parser(...)` block alongside `whisper`, `rvm`, `demucs`, `ui`:

```python
sub.add_parser("music_structure", help="all-in-one music structure analyzer (PyTorch + allin1)")
```

Add `music_structure` to the `all` dispatch so `montaj install all` gets it too.

**Step 2: Add `_ensure_music_structure()` helper**

```python
def _ensure_music_structure() -> bool:
    print("→ installing music_structure deps (allin1 + torch + natten + madmom)…")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-e", ".[music_structure]"])
    if r.returncode != 0:
        print("error: pip install .[music_structure] failed", file=sys.stderr)
        print("hint: NATTEN compilation can fail on Linux/Windows — see https://github.com/SHI-Labs/NATTEN", file=sys.stderr)
        return False
    print("✓ music_structure deps installed")

    # Prewarm: trigger model weight download so first real run is fast.
    # Try two strategies:
    #   (a) if allin1 exposes an explicit download/prewarm API, use it
    #   (b) else analyze a tiny silent WAV, which forces the full weight
    #       download and validates the inference path end-to-end.
    print("→ prewarming allin1 model weights…")
    try:
        import allin1  # noqa: F401
        if hasattr(allin1, "download_models"):
            allin1.download_models()
            print("✓ allin1 model weights ready")
        else:
            # Fallback: analyze a 1-second silent WAV. This downloads weights and
            # also verifies the full inference pipeline works on this platform.
            import tempfile, wave, struct
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tf:
                silent_path = tf.name
            try:
                # 1 second of silence at 22050 Hz, mono, 16-bit.
                with wave.open(silent_path, "wb") as w:
                    w.setnchannels(1)
                    w.setsampwidth(2)
                    w.setframerate(22050)
                    w.writeframes(b"\x00\x00" * 22050)
                allin1.analyze(silent_path)
                print("✓ allin1 model weights ready (verified on silent sample)")
            finally:
                try: os.unlink(silent_path)
                except Exception: pass
    except Exception as e:
        # Non-fatal: first real run will download. Print a warning and continue.
        print(f"warning: could not prewarm allin1: {e}", file=sys.stderr)
        print("note: first analysis run will download weights (~several hundred MB).")

    return True
```

The prewarm path is best-effort — if it fails, the step still works, first run is just slower. Don't fail the install for a prewarm failure.

**Step 3: Wire the dispatch**

In the `handle(args)` function, add:

```python
elif args.component == "music_structure":
    ok &= _ensure_music_structure()
```

And in the `all` branch:

```python
if args.component == "all":
    ok &= _ensure_whisper("base.en")
    ok &= _ensure_rvm()
    ok &= _ensure_demucs()
    ok &= _ensure_music_structure()  # NEW
    ok &= _ensure_ui()
```

**Step 4: Verification**

```bash
montaj install --help
# Expect: `music_structure` listed as one of the components.

# Full install (skip in CI if NATTEN compilation is risky):
montaj install music_structure
# Expect: pip install succeeds, prewarm attempts (may warn if no prewarm API).
```

On failure, the error message should point at the NATTEN install docs. Most common failure is NATTEN not having a prebuilt wheel for the user's Python/torch/OS combination; next most common is CUDA mismatch on Linux.

---

### Task 3: `steps/music_structure.py` + `.json`

**Files:**
- Create: `steps/music_structure.py`
- Create: `steps/music_structure.json`

**Context:**
Single input (audio file), single output (JSON). Follows the step conventions: argparse, `fail()` on error, stdout = result path, stderr = JSON errors, exit 0/1.

Lazy-import `allin1` inside the handler so the module imports cleanly without the extras installed (consistent with the connector pattern we use for Kling/Gemini SDKs — see `docs/CONNECTORS.md` contract rules). If `allin1` isn't installed, fail with a pointer to `montaj install music_structure`.

**Step 1: Verify the `allin1` API surface**

Before coding, check the README and `allin1` source:
- Is the entry point `allin1.analyze(path)` or something else?
- What does the result object look like? Fields for `bpm`, `beats`, `downbeats`, `segments`?
- Does each segment have `{start, end, label}`?
- What labels are possible (intro, verse, chorus, bridge, outro, solo, instrumental, ...)?
- Does `analyze()` take a GPU/CPU device parameter? Any batch option?
- Is there a way to suppress its progress printing, or do we need to redirect stderr?

Output schema is derived from what `allin1` actually returns. The plan below is a reasonable guess — verify and adjust.

**Step 2: Create `steps/music_structure.json`**

```json
{
  "name": "music_structure",
  "description": "Analyze music structure (tempo, beats, downbeats, labeled segments) via all-in-one. Outputs JSON to stdout.",
  "input": {
    "type": "audio",
    "description": "Audio file (wav or mp3)"
  },
  "output": {
    "type": "json",
    "description": "Music structure JSON: tempo, beats[], downbeats[], segments[{start, end, label}]"
  },
  "params": [
    {"name": "input", "type": "path", "required": true, "description": "Audio file to analyze"}
  ]
}
```

No `--out` param and no optional params. Output is a small JSON blob printed directly to stdout — matches the `probe.py` / `virtual_to_original.py` / `waveform_image.py` pattern for steps whose result is structured data rather than bulk files. `transcribe` and `stem_separation` do use `--out`, but those write auxiliary files (SRT, stem WAVs) and print a path reference to stdout; that pattern doesn't fit here because our entire output is the JSON itself. If a caller wants a file, they redirect stdout.

**Step 3: Create `steps/music_structure.py`**

Follow the `probe.py` pattern: parse args, run the analysis, `print(json.dumps(result))` to stdout. No file writing, no `--out` flag, no `check_output()` (that convention is for steps that write a file and then echo its path — doesn't apply here).

```python
#!/usr/bin/env python3
"""Analyze music structure via all-in-one (mir-aidj/all-in-one).

Outputs JSON with tempo, beats, downbeats, and labeled segments to stdout.
Runs PyTorch models locally — no network at runtime (after weights are cached).
"""
import json, sys, os, argparse

# Make lib/ importable (for `common`).
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
from common import fail, require_file


def main():
    p = argparse.ArgumentParser(description="Analyze music structure via all-in-one")
    p.add_argument("--input", required=True, help="Audio file (wav/mp3)")
    args = p.parse_args()

    require_file(args.input)

    try:
        import allin1
    except ImportError:
        fail(
            "missing_dep",
            "allin1 is not installed. Run: montaj install music_structure"
        )

    try:
        result = allin1.analyze(args.input)
    except Exception as e:
        fail("analysis_failed", f"allin1.analyze() failed: {e}")

    # Normalize into Montaj's JSON shape. Exact field names depend on the
    # allin1 result object — verify in Task 3 Step 1 before implementing.
    # Below assumes allin1's result has `.bpm`, `.beats`, `.downbeats`,
    # `.segments`, with each segment having `.start`, `.end`, `.label`.
    payload = {
        "tempo":     float(result.bpm),
        "beats":     [float(t) for t in result.beats],
        "downbeats": [float(t) for t in result.downbeats],
        "segments": [
            {
                "start": float(seg.start),
                "end":   float(seg.end),
                "label": str(seg.label),
            }
            for seg in result.segments
        ],
    }

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
```

Notes on convention alignment with the reviewer's feedback:
- **No `--out`.** Matches `probe.py` / `virtual_to_original.py`. Callers redirect stdout if they want a file. The global `--out` at the CLI layer is forwarded to the step only if the step accepts it (ours doesn't); the CLI wrapper in Task 4 omits the forwarding.
- **No `check_output()` helper.** That convention (see `lib/common.py`) is for steps that write a file and then echo its path to verify the file is non-empty before success-exiting. Music structure prints JSON content, no file to check.
- **No `run()` helper.** `run()` is for subprocess invocations; `allin1.analyze()` is an in-process Python call. `try/except` + `fail()` is the right translation path.

**Step 4: Tests**

`tests/test_music_structure.py` — mock the `allin1` module to avoid requiring the heavy install. Use `types.SimpleNamespace` for the mock result object so tests read clearly:

```python
import json, subprocess, sys, types
from pathlib import Path

def _fake_result():
    """Mock of allin1.analyze()'s return value. Mirrors the documented
    attributes: bpm (float), beats (list[float]), downbeats (list[float]),
    segments (list with .start/.end/.label attributes)."""
    Segment = types.SimpleNamespace
    return types.SimpleNamespace(
        bpm=120.0,
        beats=[0.5, 1.0, 1.5, 2.0],
        downbeats=[0.5, 2.5],
        segments=[
            Segment(start=0.0,  end=10.0, label="intro"),
            Segment(start=10.0, end=30.0, label="verse"),
            Segment(start=30.0, end=60.0, label="chorus"),
        ],
    )

def test_module_imports_without_allin1(monkeypatch):
    # Ensure `import steps.music_structure` doesn't fail when allin1 is absent.
    # allin1 is lazy-imported inside main(), so import of the module alone is safe.
    monkeypatch.setitem(sys.modules, "allin1", None)  # force ImportError on use
    # Just importing the script file must not raise.
    import importlib.util
    spec = importlib.util.spec_from_file_location("music_structure", "steps/music_structure.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # loads without running main()

def test_produces_expected_json(monkeypatch, tmp_path):
    # Create a fake allin1 module and inject into sys.modules
    fake_allin1 = types.ModuleType("allin1")
    fake_allin1.analyze = lambda path: _fake_result()
    monkeypatch.setitem(sys.modules, "allin1", fake_allin1)

    audio = tmp_path / "song.wav"
    audio.write_bytes(b"")  # require_file only checks existence

    # Run the step as a subprocess so we exercise the main() entrypoint end-to-end.
    # (Alternative: import and call main() with patched argv.)
    # ... either approach is fine; pick one and be consistent with other tests.

def test_missing_input_fails(tmp_path):
    # --input to a non-existent file → fail("file_not_found", ...) → exit 1.
    ...

def test_allin1_exception_translates_to_fail(monkeypatch):
    # allin1.analyze raises → fail("analysis_failed", ...) → exit 1 with JSON error on stderr.
    ...
```

The `SimpleNamespace` fixture makes the mock result's shape explicit and readable. If `allin1`'s actual result class exposes additional fields or uses different names, update `_fake_result()` after Step 1 verification.

**Step 5: Manual smoke test**

```bash
cd /Users/Sam/Work/ByCrux/dev/montaj
# Requires `montaj install music_structure` to have succeeded first.
python3 steps/music_structure.py --input /path/to/test.mp3 > /tmp/structure.json
# Expect: /tmp/structure.json contains the JSON with tempo/beats/downbeats/segments.

python3 -c 'import json; d = json.load(open("/tmp/structure.json")); print("tempo", d["tempo"], "beats", len(d["beats"]), "downbeats", len(d["downbeats"]), "segments", len(d["segments"]))'
# Expect: reasonable counts for the track.
```

---

### Task 4: `cli/commands/music_structure.py` + docs catalog entry

**Files:**
- Create: `cli/commands/music_structure.py`
- Modify: `docs/ARCHITECTURE.md`

**Context:**
Thin CLI wrapper. Positional `input` (required single-file input, matches the repo's pattern — see `docs/plans/2026-04-16-connectors.md` Task 11 note for the positional-vs-named rule). The step does not accept `--out`, so the wrapper does NOT forward it; users can redirect stdout if they want a file.

**Step 1: Create the wrapper**

```python
#!/usr/bin/env python3
"""montaj music-structure — analyze music structure (tempo, beats, downbeats, segments)."""
import os, subprocess, sys
from cli.main import MONTAJ_ROOT, add_global_flags
from cli.output import emit, emit_error


def register(subparsers):
    p = subparsers.add_parser("music-structure", help="Analyze music structure via all-in-one")
    p.add_argument("input", help="Audio file (wav/mp3)")
    add_global_flags(p)
    p.set_defaults(func=handle)


def handle(args):
    if not os.path.isfile(args.input):
        emit_error("not_found", f"File not found: {args.input}")
        # emit_error calls sys.exit(1) internally (see cli/output.py:31); never returns.

    cmd = [
        sys.executable,
        os.path.join(MONTAJ_ROOT, "steps", "music_structure.py"),
        "--input", args.input,
    ]
    # Note: do NOT forward args.out — the step doesn't accept --out. Output is
    # always JSON-on-stdout (matches probe.py convention). Users redirect stdout
    # if they want a file.

    result = subprocess.run(cmd, capture_output=True, text=True)
    emit(result, as_json=args.json, quiet=args.quiet)
```

**Note on `as_json=args.json`:** `cli/output.py:19` guards against double-wrapping — `if as_json and output and not output.startswith(("{", "["))`. Since music_structure's stdout is always a JSON object starting with `{`, passing `as_json=args.json` is a safe no-op on JSON output. We match `probe.py`'s pattern here (probe also uses `args.json`); `transcribe` and `stem_separation` hardcode `False` because their stdout is a path-descriptor-JSON where wrapping isn't wanted either way. Both patterns are correct; match the closest-shaped precedent (probe).

**Step 2: Register the command**

Add `music_structure` to the import list and registration block in `cli/main.py` — match whatever pattern the existing step commands use (check `cli/main.py:17-29` for the `from cli.commands import (...)` block).

**Step 3: Update `docs/ARCHITECTURE.md`** (folded in from the former Task 5 — one-line doc edit, not worth its own task)

Under the `## Native Steps` section, add a new "Music analysis" subcategory:

```markdown
### Music analysis

| Step | What it does |
|------|-------------|
| `montaj/music_structure` | Tempo, beats, downbeats, and labeled segments (intro/verse/chorus/etc.) via [all-in-one](https://github.com/mir-aidj/all-in-one). Requires `montaj install music_structure`. Best on Western pop; accuracy drops for non-Western, classical, jazz. |
```

**Step 4: Verification**

```bash
montaj --help | grep music-structure
# Expect: music-structure listed.

montaj music-structure --help
# Expect: shows the positional `input` and global flags.

# End-to-end (requires install):
montaj music-structure /path/to/test.mp3 > /tmp/structure.json
# Expect: JSON written to /tmp/structure.json via shell redirect.

# With --out (the global flag is accepted by argparse but ignored by the step — no-op):
montaj music-structure /path/to/test.mp3 --out /tmp/ignored.json
# Output still goes to stdout. The ignored --out is a known pre-existing pattern —
# probe.py has the same behavior. Don't solve it here.

# Doc update:
grep -c "music_structure" /Users/Sam/Work/ByCrux/dev/montaj/docs/ARCHITECTURE.md
# Expect: >= 1
```

---

## Verification Checklist

- [ ] `pyproject.toml` has `[project.optional-dependencies].music_structure` with `allin1>=<version>`.
- [ ] `montaj install music_structure` appears in `montaj install --help`.
- [ ] `montaj install music_structure` completes successfully (or fails with a clear NATTEN hint if the platform can't compile it).
- [ ] After install, `python3 -c 'import allin1'` succeeds.
- [ ] Model weights are either prewarmed (via `allin1.download_models()` if the API exists) or will download lazily on first run (warning printed, no failure).
- [ ] `steps/music_structure.py` imports cleanly without `allin1` installed (lazy import rule, same as connectors).
- [ ] `steps/music_structure.py` fails with a helpful error pointing at `montaj install music_structure` when `allin1` is missing.
- [ ] Step produces JSON with `tempo` (number), `beats` (array of numbers), `downbeats` (array of numbers), `segments` (array of `{start, end, label}`).
- [ ] `pytest tests/test_music_structure.py -v` passes.
- [ ] CLI: `montaj music-structure <file> --out <path>` works end-to-end on a real audio file.
- [ ] HTTP: `POST /api/steps/music_structure` works (auto-discovered via `scan_steps`). `curl -s -X POST http://localhost:8080/api/steps/music_structure -H 'Content-Type: application/json' -d '{"input":"<path>"}'` returns the JSON.
- [ ] MCP: `cli/mcp_schema.py` output includes `music-structure` with `input` as required. `install` is expected to remain absent from MCP tools per `_SKIP_COMMANDS`.
- [ ] `docs/ARCHITECTURE.md` lists `montaj/music_structure` under a Music analysis subcategory.
- [ ] `pytest tests/ -q` still passes overall.
