# Audio Tracks Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Replace `audio.music` with a proper `audio.tracks` array so montaj supports multiple independent audio tracks, each with volume, trimming, and timeline positioning — rendered via `normalize=0` amix in ffmpeg. Audio tracks appear as rows in the Timeline UI.

**Architecture:** `AudioTrack` mirrors the video item shape (`start`, `end`, `inPoint`, `outPoint`, `volume`, `muted`). Audio mixing logic is extracted from `compose.js` into a new `render/mix-audio.js` module — compose stays focused on video compositing and calls mix-audio for everything audio. The Timeline renders audio tracks as colored bars below visual tracks (no interaction yet). PreviewPlayer plays the first unmuted audio track for preview.

**Tech Stack:** TypeScript (schema), Node.js (render pipeline), React (Timeline UI)

---

### Task 1: Add `AudioTrack` type and update Project schema

**Files:**
- Modify: `ui/src/lib/project.ts`

**Context:**
`Project.audio` is currently `Record<string, unknown>` — a loose bag. Replace with a typed `{ tracks: AudioTrack[] }`. Add `volume?: number` to `VisualItem` so video clips can have their audio level set (CapCut-style). Ducking moves from a music-level concept to a per-track option on `AudioTrack`.

**Step 1: Read `ui/src/lib/project.ts`**

Confirm current `VisualItem`, `Project`, and `audio` field shapes.

**Step 2: Add `AudioTrack` interface**

Insert after the `Word` interface (before `CaptionSegment`):

```typescript
export interface AudioTrack {
  id: string
  src: string
  start: number          // position on project timeline (seconds)
  end: number
  volume?: number        // 0.0–2.0, default 1.0
  inPoint?: number       // offset into source file (seconds)
  outPoint?: number      // end offset in source file (seconds)
  label?: string         // display name, defaults to filename
  muted?: boolean
  ducking?: {
    enabled: boolean
    depth?: number       // dB, default -12
    attack?: number      // seconds, default 0.3
    release?: number     // seconds, default 0.5
  }
}
```

**Step 3: Add `volume?` to `VisualItem`**

In the `VisualItem` interface, add after `opacity?: number`:
```typescript
  volume?: number        // video audio level 0.0–2.0, default 1.0 (ignored for images)
```

**Step 4: Update `Project.audio`**

Change:
```typescript
  audio: Record<string, unknown>
```
to:
```typescript
  audio: { tracks: AudioTrack[] }
```

**Step 5: Verify TypeScript compiles**

```bash
cd /Users/Sam/Work/ByCrux/dev/montaj/ui && npx tsc --noEmit
```
Expected: errors (PreviewPlayer and render.js now have broken references) — that's fine, they get fixed in later tasks. Just confirm no NEW type errors are introduced in `project.ts` itself.

---

### Task 2: Create `render/mix-audio.js`

**Files:**
- Create: `render/mix-audio.js`

**Context:**
This module owns all audio-track mixing logic. `compose.js` will import from it. Video item audio (the `!item.muted` block in the video compositing loop) stays inline in `compose.js` — it's interleaved with video compositing and can't be cleanly separated. `mix-audio.js` handles only the independent `audio.tracks` entries.

There are three exported functions:

1. **`buildAudioTrackInputs(audioTracks)`** — returns ffmpeg `-ss`/`-to`/`-i` arg arrays for each unmuted audio track. Called when building the inputs list in `compose()`.

2. **`buildAudioTrackFilters(audioTracks, baseInputIdx, currentAudioLabel)`** — builds filter_complex parts that delay, volume-scale, and amix each track into the running audio label. Returns `{ filterParts, audioLabel }`. Handles per-track ducking.

3. **`mixAudioIntoVideo(videoPath, audioTracks, outputPath)`** — used by the chunked path to add audio tracks to the final assembled video in a re-mux pass (video stream copied, no re-encode).

**Step 1: Write the file**

Create `/Users/Sam/Work/ByCrux/dev/montaj/render/mix-audio.js`:

```javascript
/**
 * mix-audio.js — Independent audio track mixing for the montaj render pipeline.
 *
 * Handles project.audio.tracks: per-track delay, volume, trimming, and amix.
 * Video item audio (muted flag on VisualItems) is handled inline in compose.js.
 */
import { spawnSync } from 'child_process'

const FFMPEG_TIMEOUT_MS = 600_000

/**
 * Build ffmpeg input args for all unmuted audio tracks.
 * Call once per track; push returned args into the inputs array before calling ffmpeg.
 *
 * @param {Array} audioTracks  — project.audio.tracks
 * @returns {string[]}         — flat array of ffmpeg input args
 */
export function buildAudioTrackInputs(audioTracks = []) {
  const args = []
  for (const track of audioTracks) {
    if (track.muted) continue
    const inPt  = track.inPoint  ?? 0
    const outPt = track.outPoint ?? null
    if (inPt > 0)     args.push('-ss', String(inPt))
    if (outPt !== null) args.push('-to', String(outPt))
    args.push('-i', track.src)
  }
  return args
}

/**
 * Build filter_complex parts that mix all unmuted audio tracks into the running audio stream.
 *
 * @param {Array}  audioTracks       — project.audio.tracks
 * @param {number} baseInputIdx      — ffmpeg input index of the first audio track
 * @param {string} currentAudioLabel — current audio label in the filter graph (e.g. '[canvas_a]')
 * @returns {{ filterParts: string[], audioLabel: string }}
 */
export function buildAudioTrackFilters(audioTracks = [], baseInputIdx, currentAudioLabel) {
  const filterParts = []
  let audioLabel = currentAudioLabel
  let offset = 0  // counts only unmuted tracks (maps to input index)

  for (const track of audioTracks) {
    if (track.muted) continue

    const inputIdx = baseInputIdx + offset
    const vol      = track.volume ?? 1.0
    const delayMs  = Math.round((track.start ?? 0) * 1000)
    const audioIn  = audioLabel.startsWith('[') ? audioLabel : `[${audioLabel}]`

    if (track.ducking?.enabled) {
      const depth   = track.ducking.depth   ?? -12
      const attack  = track.ducking.attack  ?? 0.3
      const release = track.ducking.release ?? 0.5
      filterParts.push(
        `${audioIn}asplit=2[speech${offset}][sc${offset}]`,
        `[${inputIdx}:a]adelay=${delayMs}:all=1,volume=${vol}[mscaled${offset}]`,
        `[mscaled${offset}][sc${offset}]sidechaincompress=threshold=0.02:ratio=4:attack=${attack * 1000}:release=${release * 1000}[ducked${offset}]`,
        `[speech${offset}][ducked${offset}]amix=inputs=2:duration=first:normalize=0[aout${offset}]`,
      )
      audioLabel = `[aout${offset}]`
    } else {
      filterParts.push(
        `[${inputIdx}:a]adelay=${delayMs}:all=1,volume=${vol}[atrack${offset}]`,
        `${audioIn}[atrack${offset}]amix=inputs=2:duration=longest:normalize=0[amid${offset}]`,
      )
      audioLabel = `[amid${offset}]`
    }

    offset++
  }

  return { filterParts, audioLabel }
}

/**
 * Mix audio tracks into a pre-rendered silent/chunk video file.
 * Used by composeChunked() final pass: video stream is copied, audio is re-encoded.
 *
 * @param {string} videoPath   — path to the pre-rendered video (no audio or silent)
 * @param {Array}  audioTracks — project.audio.tracks
 * @param {string} outputPath
 */
export function mixAudioIntoVideo(videoPath, audioTracks, outputPath) {
  const unmuted = (audioTracks ?? []).filter(t => !t.muted)
  if (unmuted.length === 0) {
    // No audio tracks — just copy video as-is
    const result = spawnSync('ffmpeg', [
      '-y', '-i', videoPath, '-c', 'copy', outputPath,
    ], { encoding: 'utf8', timeout: FFMPEG_TIMEOUT_MS })
    if (result.status !== 0) throw new Error(`ffmpeg copy failed:\n${result.stderr}`)
    return
  }

  // Build inputs
  const inputs = ['-i', videoPath]
  inputs.push(...buildAudioTrackInputs(unmuted))

  // Build filter graph — start from [0:a] (video's audio stream, may be silent)
  const { filterParts, audioLabel } = buildAudioTrackFilters(unmuted, 1, '[0:a]')

  const result = spawnSync('ffmpeg', [
    '-y', ...inputs,
    '-filter_complex', filterParts.join(';'),
    '-map', '0:v',
    '-map', audioLabel,
    '-c:v', 'copy',
    '-c:a', 'aac', '-b:a', '192k',
    '-movflags', '+faststart',
    outputPath,
  ], { encoding: 'utf8', timeout: FFMPEG_TIMEOUT_MS })

  if (result.status !== 0) throw new Error(`ffmpeg audio mix failed:\n${result.stderr}`)
}
```

**Step 2: Verify the file parses**

```bash
node --input-type=module --eval "import './render/mix-audio.js'" 2>&1
```
Expected: no output (clean import, no syntax errors)

---

### Task 3: Update `render/compose.js`

**Files:**
- Modify: `render/compose.js`

**Context:**
`compose.js` currently has all audio logic inline. After this task:
- `audio.music` → `audio.tracks`
- Music inputs + filters replaced by calls to `buildAudioTrackInputs` / `buildAudioTrackFilters`
- `mixMusicIntoVideo` removed, replaced by `mixAudioIntoVideo` from mix-audio.js
- `musicInputIdx` renamed to `audioTrackBaseIdx` for clarity
- Video item audio (the `!item.muted` adelay/amix block) stays inline — it's interleaved with video compositing
- `computeTotalDuration` updated to also consider audio track end times

**Step 1: Read `render/compose.js` lines 1–100**

Confirm current imports and `compose()` signature.

**Step 2: Add import**

At the top of the file, after existing imports, add:
```javascript
import { buildAudioTrackInputs, buildAudioTrackFilters, mixAudioIntoVideo } from './mix-audio.js'
```

**Step 3: Update `computeTotalDuration`**

Change from:
```javascript
function computeTotalDuration(imageItems, videoItems, puppeteerSegments) {
  const allEnds = [
    ...imageItems.map(i => i.end ?? 0),
    ...videoItems.map(i => i.end ?? 0),
    ...puppeteerSegments.map(s => s.endSeconds ?? 0),
  ]
  return allEnds.length > 0 ? Math.max(...allEnds) : 0
}
```
to:
```javascript
function computeTotalDuration(imageItems, videoItems, puppeteerSegments, audioTracks = []) {
  const allEnds = [
    ...imageItems.map(i => i.end ?? 0),
    ...videoItems.map(i => i.end ?? 0),
    ...puppeteerSegments.map(s => s.endSeconds ?? 0),
    ...audioTracks.map(t => t.end ?? 0),
  ]
  return allEnds.length > 0 ? Math.max(...allEnds) : 0
}
```

**Step 4: Update `compose()` — extract audio tracks, replace music references**

In `compose()`:

Replace lines 82–84:
```javascript
const music    = projectJson.audio?.music
const hasMusic = !!(music?.src)
```
with:
```javascript
const audioTracks = projectJson.audio?.tracks ?? []
const hasAudio    = audioTracks.some(t => !t.muted)
```

Replace line 108:
```javascript
const musicInputIdx = N + Q
```
with:
```javascript
const audioTrackBaseIdx = N + Q
```

Replace line 110:
```javascript
const totalDuration = computeTotalDuration(imageItems, videoItems, puppeteerSegments)
```
with:
```javascript
const totalDuration = computeTotalDuration(imageItems, videoItems, puppeteerSegments, audioTracks)
```

Replace lines 141–145 (music input):
```javascript
  // Music — optional inPoint seeks into the file (e.g. lyrics_video crops to lyrics window)
  if (hasMusic) {
    if (music.inPoint) inputs.push('-ss', String(music.inPoint))
    inputs.push('-i', music.src)
  }
```
with:
```javascript
  // Independent audio tracks
  inputs.push(...buildAudioTrackInputs(audioTracks))
```

In the video item loop, update the video audio block (lines ~199–206) to use `item.volume`:
```javascript
      if (!item.muted) {
        const vol     = item.volume ?? 1.0
        const delayMs = Math.round((item.start ?? 0) * 1000)
        const audioIn = audioLabel.startsWith('[') ? audioLabel : `[${audioLabel}]`
        filterParts.push(`[${i}:a]asetpts=PTS-STARTPTS[apts${i}]`)
        filterParts.push(`[apts${i}]adelay=${delayMs}:all=1,volume=${vol}[vida${i}]`)
        filterParts.push(`${audioIn}[vida${i}]amix=inputs=2:duration=longest:normalize=0[amix${i}]`)
        audioLabel = `[amix${i}]`
      }
```

Replace lines 243–266 (Step 6 music ducking/mixing) with:
```javascript
  // Step 6: Mix independent audio tracks
  if (hasAudio) {
    const { filterParts: audioFilterParts, audioLabel: newLabel } =
      buildAudioTrackFilters(audioTracks, audioTrackBaseIdx, audioLabel)
    filterParts.push(...audioFilterParts)
    audioLabel = newLabel
  }
```

**Step 5: Update `composeChunked()` — replace music references**

Replace lines 349–350:
```javascript
  const music       = projectJson.audio?.music
  const hasMusic    = !!(music?.src)
```
with:
```javascript
  const audioTracks = projectJson.audio?.tracks ?? []
  const hasAudio    = audioTracks.some(t => !t.muted)
```

Replace line 403:
```javascript
    const chunkProject = { ...projectJson, audio: undefined }
```
with:
```javascript
    const chunkProject = { ...projectJson, audio: { tracks: [] } }
```

Replace lines 418–428 (music final pass):
```javascript
  const preMusicPath = hasMusic ? outputPath.replace(/(\.\w+)$/, '_nomusic$1') : outputPath
  concatVideoFiles(chunkPaths, preMusicPath)
  if (!process.env.MONTAJ_KEEP_CHUNKS) {
    for (const p of chunkPaths) rmSync(p, { force: true })
  }

  // Add music in a final re-mux pass (video stream copied, no re-encode)
  if (hasMusic) {
    mixMusicIntoVideo(preMusicPath, music, outputPath)
    rmSync(preMusicPath, { force: true })
  }
```
with:
```javascript
  const preAudioPath = hasAudio ? outputPath.replace(/(\.\w+)$/, '_noaudio$1') : outputPath
  concatVideoFiles(chunkPaths, preAudioPath)
  if (!process.env.MONTAJ_KEEP_CHUNKS) {
    for (const p of chunkPaths) rmSync(p, { force: true })
  }

  if (hasAudio) {
    mixAudioIntoVideo(preAudioPath, audioTracks, outputPath)
    rmSync(preAudioPath, { force: true })
  }
```

**Step 6: Remove `mixMusicIntoVideo` function**

Delete lines 457–482 (the `mixMusicIntoVideo` function) entirely — it's replaced by `mixAudioIntoVideo` in mix-audio.js.

**Step 7: Update `computeTotalDuration` export and file header comment**

Update the header comment (line 9) from:
```
 *   - optionally: music file (from projectJson.audio.music)
```
to:
```
 *   - optionally: audio tracks (from projectJson.audio.tracks)
```

**Step 8: Smoke test**

```bash
cd /Users/Sam/Work/ByCrux/dev/montaj
node --input-type=module --eval "import './render/compose.js'" 2>&1
```
Expected: no output (clean import)

---

### Task 4: Update `render/render.js`

**Files:**
- Modify: `render/render.js`

**Context:**
Three places reference `audio.music`: `resolveProjectPaths`, `validateProjectFiles`, and the ffmpeg-drawtext early-exit branch. All need updating to `audio.tracks`.

**Step 1: Read `render/render.js` lines 370–460**

Confirm current `resolveProjectPaths` and `validateProjectFiles` implementations.

**Step 2: Update `resolveProjectPaths`**

Replace:
```javascript
  if (projectJson.audio?.music?.src) {
    const src = projectJson.audio.music.src
    if (!src.startsWith('/')) {
      projectJson.audio.music.src = resolve(projectDir, src)
    }
    const actual = resolveFilePath(projectJson.audio.music.src)
    if (actual) projectJson.audio.music.src = actual
  }
```
with:
```javascript
  for (const track of projectJson.audio?.tracks ?? []) {
    if (track.src && !track.src.startsWith('/')) {
      track.src = resolve(projectDir, track.src)
    }
    const actual = resolveFilePath(track.src)
    if (actual) track.src = actual
  }
```

**Step 3: Update `validateProjectFiles`**

Replace:
```javascript
  if (projectJson.audio?.music?.src && !resolveFilePath(projectJson.audio.music.src)) {
    missing.push(projectJson.audio.music.src)
  }
```
with:
```javascript
  for (const track of projectJson.audio?.tracks ?? []) {
    if (track.src && !resolveFilePath(track.src)) missing.push(track.src)
  }
```

**Step 4: Update ffmpeg-drawtext branch**

Replace lines 102–103:
```javascript
    const audioSrc = projectJson.audio?.music?.src
    if (!audioSrc) fail('missing_audio', 'renderMode ffmpeg-drawtext requires audio.music.src')
```
with:
```javascript
    const firstAudioTrack = (projectJson.audio?.tracks ?? []).find(t => !t.muted)
    if (!firstAudioTrack?.src) fail('missing_audio', 'renderMode ffmpeg-drawtext requires at least one unmuted audio track')
    const audioSrc = firstAudioTrack.src
```

Also update line 116:
```javascript
      '--audio',    audioSrc,
```
stays the same — `audioSrc` is already set above.

**Step 5: Smoke test — missing audio error**

```bash
cd /Users/Sam/Work/ByCrux/dev/montaj
echo '{"version":"1","id":"x","status":"final","name":"t","workflow":"lyrics_video","editingPrompt":"","settings":{"resolution":[1080,1920],"fps":30},"tracks":[],"captions":{"style":"word-by-word","segments":[{"text":"hi","start":0,"end":1,"words":[{"word":"hi","start":0,"end":1}]}]},"audio":{"tracks":[]},"assets":[],"renderMode":"ffmpeg-drawtext"}' > /tmp/test_audio_tracks.json
node render/render.js /tmp/test_audio_tracks.json
```
Expected: stderr `"error":"missing_audio"`, exit 1

---

### Task 5: Update `PreviewPlayer.tsx`

**Files:**
- Modify: `ui/src/components/PreviewPlayer.tsx`

**Context:**
PreviewPlayer uses `audio.music.src` to create an HTML `<audio>` element for canvas-mode preview. With the new schema, use the first unmuted audio track (`audio.tracks[0]`). The preview player only needs one audio element — multi-track mixing is render-only.

**Step 1: Read `PreviewPlayer.tsx` lines 415–425 and 878–892**

Confirm the two `audio.music` reference sites.

**Step 2: Update inPoint sync (line ~420)**

Replace:
```typescript
    const inPoint = (project.audio?.music as { inPoint?: number } | undefined)?.inPoint ?? 0
```
with:
```typescript
    const inPoint = project.audio?.tracks?.find(t => !t.muted)?.inPoint ?? 0
```

**Step 3: Update audio element render (lines ~883–886)**

Replace:
```typescript
      {isCanvasProject && (project.audio?.music as { src?: string } | undefined)?.src && (
        <audio
          ...
          src={fileUrl((project.audio.music as { src: string }).src)}
```
with:
```typescript
      {isCanvasProject && project.audio?.tracks?.find(t => !t.muted)?.src && (
        <audio
          ...
          src={fileUrl(project.audio.tracks.find(t => !t.muted)!.src)}
```

**Step 4: Verify TypeScript compiles**

```bash
cd /Users/Sam/Work/ByCrux/dev/montaj/ui && npx tsc --noEmit
```
Expected: no errors

---

### Task 6: Timeline UI — audio track rows

**Files:**
- Modify: `ui/src/components/Timeline.tsx`

**Context:**
Add audio track rows below visual tracks. Each row shows the audio track as a colored bar spanning its `start`–`end` position on the timeline. Label shows `track.label` or the filename. A music note icon on the left. No drag/resize — display only for now. Muted tracks are shown dimmed.

The Timeline already renders visual tracks in a loop — add a new section after them.

**Step 1: Read `Timeline.tsx` to find where visual track rows are rendered**

Search for the JSX that maps over `allTracks` and renders track rows. Read from line 300 to end of file to find the render section.

**Step 2: Add audio tracks to `totalDuration` calculation**

Near the top of the component (after `allTracks` is defined), update:
```typescript
  const totalDuration  = allTracks.flat().reduce((m, i) => Math.max(m, i.end ?? 0), 0)
```
to:
```typescript
  const audioTracks    = project.audio?.tracks ?? []
  const totalDuration  = Math.max(
    allTracks.flat().reduce((m, i) => Math.max(m, i.end ?? 0), 0),
    audioTracks.reduce((m, t) => Math.max(m, t.end ?? 0), 0),
  )
```

**Step 3: Import `Music2` icon**

Add `Music2` to the lucide-react import at line 3:
```typescript
import { Volume2, VolumeX, Music2 } from 'lucide-react'
```

**Step 4: Add audio track rows after visual tracks in JSX**

Find the closing of the visual tracks section in the JSX. After it, add:

```tsx
{/* Audio tracks */}
{audioTracks.map((track) => {
  const left  = totalDuration > 0 ? (track.start / totalDuration) * 100 * zoom : 0
  const width = totalDuration > 0 ? ((track.end - track.start) / totalDuration) * 100 * zoom : 0
  const label = track.label ?? track.src.split('/').pop() ?? 'audio'
  return (
    <div key={track.id} className="relative flex items-center h-8 border-b border-white/5">
      {/* Left label */}
      <div className="absolute left-0 flex items-center gap-1 px-2 z-10 w-24 shrink-0">
        <Music2 className={`w-3 h-3 ${track.muted ? 'text-white/20' : 'text-emerald-400'}`} />
        <span className="text-[10px] text-white/40 truncate">{label}</span>
      </div>
      {/* Track bar */}
      <div className="relative flex-1 h-full" style={{ marginLeft: '6rem' }}>
        <div
          className={`absolute top-1 bottom-1 rounded ${track.muted ? 'bg-white/10' : 'bg-emerald-500/40 border border-emerald-500/60'}`}
          style={{ left: `${left}%`, width: `${width}%` }}
          title={label}
        />
      </div>
    </div>
  )
})}
```

**Step 5: Verify TypeScript compiles**

```bash
cd /Users/Sam/Work/ByCrux/dev/montaj/ui && npx tsc --noEmit
```
Expected: no errors

---

### Task 7: Update reference sites

**Files:**
- Modify: `skills/lyrics-video/SKILL.md`
- Modify: `workflows/lyrics_video.json`

**Context:**
Two places document `audio.music` that agents use when building project.json. Both need updating to `audio.tracks`.

**Step 1: Read `skills/lyrics-video/SKILL.md` and search for `audio.music`**

Find all occurrences and replace with `audio.tracks` pattern.

Specifically, the JSX path project.json structure shows:
```json
"audio": { "music": { "src": "...", "volume": 1.0, "inPoint": <audioInPoint> } }
```
Replace with:
```json
"audio": {
  "tracks": [
    { "id": "music", "src": "/abs/path/to/song.mp3", "start": 0, "end": <song_duration>, "inPoint": <audioInPoint>, "volume": 1.0, "label": "song" }
  ]
}
```

**Step 2: Update the AUDIO agent note in `workflows/lyrics_video.json`**

Find:
```
"AUDIO: Set audio.music.src to the song file. Set audio.music.inPoint to lyrics_sync output audioInPoint."
```
Replace with:
```
"AUDIO: Set audio.tracks to an array with one entry for the song: { id: 'music', src: <abs path to song>, start: 0, end: <song duration>, inPoint: <audioInPoint from lyrics_sync output>, volume: 1.0, label: 'song' }. Use montaj probe to get song duration."
```

**Step 3: Verify both files look correct**

Read both files and confirm no remaining `audio.music` references.
