# AI Video Quality Pipeline Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Improve ai_video output quality by adopting patterns from agent-free-strike: structured camera vocabulary, richer character specs, Gemini-based per-clip evaluation with retry loop, and discouraging smooth transitions.

**Architecture:** Four changes layered on the existing ai_video pipeline. (1) A camera-vocabulary sub-skill provides editorial knowledge the agent uses in Phase 1, with structured fields on scenes that the step auto-appends to composed prompts. (2) The ai-video skill is updated to discourage frame bridging — hard cuts are the default, chained mode remains available for deliberate match-cuts only. (3) Phase 1's anchor writing is enhanced to produce forensic 60-120 word character specs that get appended to every prompt as identity anchoring. (4) A new `eval_scene` step runs a Gemini-based critique + kling_generate retry loop, added to the ai_video workflow after `generate_scene`.

**Tech Stack:** Python 3, Gemini connector (`connectors/gemini.py`), Kling connector (`connectors/kling.py`), step conventions (`lib/common.py`), sub-skill markdown.

**Composed prompt structure (final shape after all tasks):**
```
[styleAnchor] [ref clause + scene prose with inline <<<image_N>>> tokens] [SHOT SCALE] [CAMERA MOVE]

--- CHARACTER/OBJECT SPECS ---
[LABEL] 60-120 word anchor text
[LABEL] 60-120 word anchor text
```

Kling accepts newlines in prompts — the `---` separator is intentional to visually delimit the identity-anchoring section from the scene prose.

**Prerequisite — extract shared helpers into `lib/ai_video.py`:** Both `kling_generate.py` and the new `eval_scene.py` need project helpers (`_find_project`, `_save_project`, `_compose_prompt`, `_resolve_ref_paths`, `_save_clip_to_project`). These are currently private functions in `steps/kling_generate.py`. Since `steps/` is not a Python package (no `__init__.py`; steps are invoked as standalone scripts with `sys.path` hacks), cross-step imports will fail at runtime. Extract these into `lib/ai_video.py` (which IS on the path) as the first task.

---

## Task 0: Extract Shared Project Helpers to `lib/ai_video.py`

**Files:**
- Create: `lib/ai_video.py`
- Modify: `steps/kling_generate.py` — replace inline helpers with imports from `lib/ai_video`
- Test: `tests/test_kling_generate_project.py` (new — tests the extracted functions)

**Step 1: Create `lib/ai_video.py`**

Move these functions from `steps/kling_generate.py` into `lib/ai_video.py`, dropping the underscore prefix (they're now public library code):

```python
"""Shared helpers for ai_video project-aware steps.

Used by kling_generate.py and eval_scene.py. Lives in lib/ so it's on
the sys.path that all step scripts set up.
"""
import json, time
from pathlib import Path
from common import fail


def resolve_workspace() -> Path:
    config_path = Path.home() / ".montaj" / "config.json"
    if config_path.exists():
        try:
            cfg = json.loads(config_path.read_text())
            if "workspaceDir" in cfg:
                return Path(cfg["workspaceDir"])
        except Exception:
            pass
    return Path.home() / "Montaj"


def find_project(project_id: str) -> tuple[Path, dict]:
    """Find and load project by ID. Returns (project_json_path, project_dict)."""
    workspace = resolve_workspace()
    for p in workspace.glob("*/project.json"):
        try:
            data = json.loads(p.read_text())
            if data.get("id") == project_id:
                return p, data
        except Exception:
            pass
    fail("not_found", f"Project {project_id} not found in {workspace}")


def save_project(path: Path, project: dict):
    """Write project JSON back to disk."""
    path.write_text(json.dumps(project, indent=2, ensure_ascii=False))


def compose_prompt(project: dict, scene: dict) -> str:
    """Compose the full Kling prompt from project context + scene prose.

    Applies: styleAnchor prefix + ref clause + inline <<<image_N>>> tokens
    at character/object label positions in the scene prompt.

    Also auto-appends:
    - [SHOT SCALE] / [CAMERA MOVE] tags from structured scene fields.
    - CHARACTER/OBJECT SPECS section from imageRefs[i].anchor (60-120 word specs).
    """
    style_anchor = project.get("storyboard", {}).get("styleAnchor", "")
    image_refs = {r["id"]: r for r in project.get("storyboard", {}).get("imageRefs", [])}

    prompt = scene["prompt"]
    ref_ids = scene.get("refImages", [])

    # Build tokens and place inline at label matches
    token_parts = []
    for i, rid in enumerate(ref_ids):
        token = f"<<<image_{i + 1}>>>"
        token_parts.append(token)
        ref = image_refs.get(rid, {})
        label = ref.get("label", "")
        if label and label in prompt:
            prompt = prompt.replace(label, f"{label} {token}", 1)

    # Prepend ref clause
    ref_clause = ""
    if token_parts:
        ref_clause = "Use the character/style from " + ", ".join(token_parts) + ". "

    parts = []
    if style_anchor:
        parts.append(style_anchor)
    if ref_clause:
        parts.append(ref_clause + prompt)
    else:
        parts.append(prompt)

    composed = " ".join(parts)

    # Auto-append camera tags from structured scene fields.
    shot_scale = scene.get("shotScale")
    camera_move = scene.get("cameraMove")
    camera_tags = []
    if shot_scale:
        camera_tags.append(f"[SHOT SCALE] {shot_scale}")
    if camera_move:
        camera_tags.append(f"[CAMERA MOVE] {camera_move.replace('-', ' ')}")
    if camera_tags:
        composed = composed + " " + " ".join(camera_tags)

    # Auto-append character/object specs from imageRefs anchors.
    specs = []
    for rid in scene.get("refImages", []):
        ref = image_refs.get(rid, {})
        anchor = ref.get("anchor", "")
        label = ref.get("label", "")
        if anchor and len(anchor) > 30:
            specs.append(f"[{label.upper()}] {anchor}")
    if specs:
        composed = composed + "\n\n--- CHARACTER/OBJECT SPECS ---\n" + "\n".join(specs)

    return composed


def resolve_ref_paths(project: dict, scene: dict) -> list[str]:
    """Resolve scene refImage IDs to file paths."""
    image_refs = {r["id"]: r for r in project.get("storyboard", {}).get("imageRefs", [])}
    paths = []
    for rid in scene.get("refImages", []):
        ref = image_refs.get(rid, {})
        ref_images = ref.get("refImages", [])
        if ref_images:
            paths.append(ref_images[0])
    return paths


def save_clip_to_project(project_path: Path, project: dict, scene: dict,
                         out_path: str, composed_prompt: str, model: str = "kling-v3-omni"):
    """Append the generated clip to tracks[0] and save the project."""
    tracks0 = project.get("tracks", [[]])[0]
    scenes = project.get("storyboard", {}).get("scenes", [])

    # Compute cumulative start from scene order
    scene_order = [s["id"] for s in scenes]
    cumulative = 0.0
    for sid in scene_order:
        if sid == scene["id"]:
            break
        existing = next(
            (c for c in tracks0 if c.get("generation", {}).get("sceneId") == sid),
            None,
        )
        if existing:
            cumulative += existing["outPoint"]
        else:
            cumulative += next(
                (s["duration"] for s in scenes if s["id"] == sid), 0
            )

    clip = {
        "id": f"clip-{scene['id']}",
        "type": "video",
        "src": out_path,
        "start": cumulative,
        "end": cumulative + scene["duration"],
        "inPoint": 0,
        "outPoint": scene["duration"],
        "generation": {
            "sceneId": scene["id"],
            "provider": "kling",
            "model": model,
            "prompt": composed_prompt,
            "refImages": scene.get("refImages", []),
            "duration": scene["duration"],
            "attempts": [],
        },
    }
    tracks0.append(clip)
    project["tracks"] = [tracks0]

    # Clear lastError on this scene
    for s in scenes:
        if s["id"] == scene["id"]:
            s.pop("lastError", None)

    # Check if all scenes have clips → set draft
    scene_ids = {s["id"] for s in scenes}
    clip_ids = {c.get("generation", {}).get("sceneId") for c in tracks0}
    for c in tracks0:
        for bs in c.get("generation", {}).get("batchShots", []):
            clip_ids.add(bs.get("sceneId"))
    if scene_ids and scene_ids <= clip_ids:
        project["status"] = "draft"

    save_project(project_path, project)


def save_error_to_project(project_path: Path, project: dict, scene_id: str, error_msg: str):
    """Record lastError on a scene and save."""
    for s in project.get("storyboard", {}).get("scenes", []):
        if s["id"] == scene_id:
            s["lastError"] = {
                "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "message": error_msg,
            }
    save_project(project_path, project)
```

**Step 2: Update `steps/kling_generate.py`**

Replace all inline helper definitions with:

```python
from lib.ai_video import (
    find_project, save_project, compose_prompt,
    resolve_ref_paths, save_clip_to_project, save_error_to_project,
)
```

Remove the old `_find_project`, `_save_project`, `_compose_prompt`, `_resolve_ref_paths`, `_save_clip_to_project`, `_save_error_to_project`, `_resolve_workspace` function definitions. Update all call sites to drop the underscore prefix.

**Step 3: Write tests for extracted functions**

Create `tests/test_ai_video_lib.py`:

```python
"""Tests for lib/ai_video.py — shared project helpers."""
import json
import pytest
from lib.ai_video import compose_prompt, resolve_ref_paths


def _make_project(style_anchor="test style", image_refs=None):
    return {
        "storyboard": {
            "styleAnchor": style_anchor,
            "imageRefs": image_refs or [],
        }
    }


def _make_scene(prompt="A dog runs", ref_images=None, shot_scale=None, camera_move=None):
    s = {"id": "scene-1", "prompt": prompt, "duration": 5, "refImages": ref_images or []}
    if shot_scale:
        s["shotScale"] = shot_scale
    if camera_move:
        s["cameraMove"] = camera_move
    return s


def test_compose_basic():
    project = _make_project()
    scene = _make_scene()
    result = compose_prompt(project, scene)
    assert "test style" in result
    assert "A dog runs" in result


def test_compose_ref_clause():
    project = _make_project(image_refs=[
        {"id": "ref1", "label": "Max", "refImages": ["/fake.png"]},
    ])
    scene = _make_scene(prompt="Max runs fast", ref_images=["ref1"])
    result = compose_prompt(project, scene)
    assert "Use the character/style from <<<image_1>>>" in result
    assert "Max <<<image_1>>> runs fast" in result


def test_compose_appends_camera_tags():
    project = _make_project()
    scene = _make_scene(shot_scale="wide", camera_move="push-in")
    result = compose_prompt(project, scene)
    assert "[SHOT SCALE] wide" in result
    assert "[CAMERA MOVE] push in" in result


def test_compose_no_camera_tags_when_absent():
    project = _make_project()
    scene = _make_scene()
    result = compose_prompt(project, scene)
    assert "[SHOT SCALE]" not in result
    assert "[CAMERA MOVE]" not in result


def test_compose_hyphen_to_space_in_camera_move():
    project = _make_project(style_anchor="")
    scene = _make_scene(camera_move="whip-pan")
    result = compose_prompt(project, scene)
    assert "[CAMERA MOVE] whip pan" in result


def test_compose_appends_character_specs():
    project = _make_project(image_refs=[
        {"id": "ref1", "label": "Rosie the Dog", "refImages": ["/fake/dog.png"],
         "anchor": "A small playful corgi with short legs, tan and golden fur with a white chest, fluffy white-tipped tail, small pointed ears, round dark eyes, bold black outlines with flat solid color fills."},
    ])
    scene = _make_scene(ref_images=["ref1"])
    result = compose_prompt(project, scene)
    assert "--- CHARACTER/OBJECT SPECS ---" in result
    assert "[ROSIE THE DOG]" in result
    assert "small playful corgi" in result


def test_compose_skips_short_anchors():
    project = _make_project(image_refs=[
        {"id": "ref1", "label": "Dog", "refImages": ["/fake/dog.png"], "anchor": "A dog"},
    ])
    scene = _make_scene(ref_images=["ref1"])
    result = compose_prompt(project, scene)
    assert "CHARACTER/OBJECT SPECS" not in result


def test_compose_camera_tags_before_specs():
    """Camera tags come before character specs in the composed prompt."""
    project = _make_project(image_refs=[
        {"id": "ref1", "label": "Max", "refImages": ["/f.png"],
         "anchor": "A golden retriever with floppy ears and warm brown eyes, medium build, golden coat."},
    ])
    scene = _make_scene(ref_images=["ref1"], shot_scale="wide", camera_move="tracking")
    result = compose_prompt(project, scene)
    scale_idx = result.index("[SHOT SCALE]")
    specs_idx = result.index("CHARACTER/OBJECT SPECS")
    assert scale_idx < specs_idx


def test_resolve_ref_paths():
    project = _make_project(image_refs=[
        {"id": "ref1", "label": "Dog", "refImages": ["/path/dog.png"]},
        {"id": "ref2", "label": "Cat", "refImages": ["/path/cat.png"]},
    ])
    scene = _make_scene(ref_images=["ref2", "ref1"])
    paths = resolve_ref_paths(project, scene)
    assert paths == ["/path/cat.png", "/path/dog.png"]
```

**Step 4: Run tests**

```bash
pytest tests/test_ai_video_lib.py -v
```

Expected: All PASS.

**Step 5: Commit**

```bash
git add lib/ai_video.py steps/kling_generate.py tests/test_ai_video_lib.py
git commit -m "refactor: extract ai_video project helpers into lib/ai_video.py for cross-step reuse"
```

---

## Task 1: Camera Vocabulary Sub-Skill

**Files:**
- Create: `skills/camera-vocabulary/SKILL.md`
- Modify: `skills/ai-video/SKILL.md` — add sub-skill reference in the sub-skills table (line ~198) + scene field docs in Phase 1
- Modify: `ui/src/lib/types/schema.ts` — add `shotScale` and `cameraMove` to Scene interface

**Step 1: Create `skills/camera-vocabulary/SKILL.md`**

```markdown
---
name: camera-vocabulary
description: "Shot scale and camera move vocabulary for ai_video scene planning. Load when writing storyboard scenes in Phase 1."
---

# Camera Vocabulary

Reference for the agent when planning ai_video scenes. Pick one shot scale and one camera move per scene during Phase 1 storyboard planning.

## Shot Scales

| Value | Framing | When to use |
|-------|---------|-------------|
| `ecu` | Extreme close-up: eyes, hands, small detail | Intimate emotion, critical object |
| `cu` | Close-up: face fills frame | Dialogue, reaction, emotion |
| `mcu` | Medium close-up: head and shoulders | Conversation, character focus |
| `medium` | Medium: waist up | Standard dialogue, action |
| `medium-wide` | Medium wide: knees up | Character in context |
| `wide` | Wide: full body + environment | Establishing, physical action |
| `establishing` | Very wide: environment dominates | Opening shots, location change |
| `aerial` | Overhead / bird's eye | Scale, geography, transition |

## Camera Moves

| Value | Motion | When to use |
|-------|--------|-------------|
| `static` | No camera movement | Let the subject's motion carry the shot |
| `push-in` | Camera moves toward subject | Building tension, drawing attention |
| `pull-back` | Camera moves away from subject | Reveal, release, ending |
| `pan-left` / `pan-right` | Horizontal rotation on axis | Following motion, surveying space |
| `tilt-up` / `tilt-down` | Vertical rotation on axis | Reveal height, follow vertical motion |
| `orbit` | Camera circles the subject | Dramatic emphasis, hero moment |
| `tracking` | Camera follows subject laterally | Walking, running, chase |
| `whip-pan` | Fast horizontal snap | Comedic timing, energy burst |
| `crane-up` / `crane-down` | Vertical camera rise/descent | Opening/closing grandeur |
| `zoom-in` / `zoom-out` | Lens zoom (not camera move) | Subtle focus shift |

## Motion Budget Rule

Every shot needs motion from EITHER the subject OR the camera — never both static.

- Subject is still (posing, waiting) → use an active camera move (push-in, orbit, crane)
- Subject is moving (running, sliding) → static or tracking camera is enough
- Both moving → risk visual chaos; only for peak energy moments

## Scene Fields

When planning scenes in Phase 1, write these structured fields on each `storyboard.scenes[i]`:

```json
{
  "id": "scene-1",
  "prompt": "...",
  "duration": 5,
  "refImages": ["ref1", "ref2"],
  "shotScale": "wide",
  "cameraMove": "push-in"
}
```

The `kling_generate` step auto-appends `[SHOT SCALE]` and `[CAMERA MOVE]` tags to the composed prompt at generation time. Do NOT write these tags in the scene prompt text.
```

**Step 2: Update ai-video SKILL.md**

In the sub-skills table (around line 198), add:

```markdown
| `camera-vocabulary` | `skills/camera-vocabulary/SKILL.md` | Planning scenes in Phase 1 — shot scale + camera move selection |
```

In Phase 1's "Scene plan" section, add to the scene field list after `refImages`:

```markdown
- **`shotScale`** — one of the values from the camera-vocabulary sub-skill (e.g. `"wide"`, `"cu"`, `"medium"`). Defaults to `"medium"` if omitted. The step auto-appends `[SHOT SCALE]` to the composed prompt.
- **`cameraMove`** — one of the values from the camera-vocabulary sub-skill (e.g. `"push-in"`, `"static"`, `"tracking"`). Defaults to `"static"` if omitted. The step auto-appends `[CAMERA MOVE]` to the composed prompt.
```

**Step 3: Update TypeScript types**

In `ui/src/lib/types/schema.ts`, add to the Scene interface (find the existing scene type):

```typescript
shotScale?: string
cameraMove?: string
```

**Step 4: Commit**

```bash
git add skills/camera-vocabulary/SKILL.md skills/ai-video/SKILL.md ui/src/lib/types/schema.ts
git commit -m "feat: add camera-vocabulary sub-skill with shot scale + camera move enums"
```

---

## Task 2: Discourage Smooth Transitions in AI-Video Skill

**Files:**
- Modify: `skills/ai-video/SKILL.md`

**Step 1: Add hard-cuts-by-default guidance**

In Phase 6 Step B (dispatch mode section, after "Picking a model"), add a new section:

```markdown
#### Transition style — hard cuts by default

Each scene is generated from scratch via text-to-video. Shot-to-shot transitions are **hard cuts**. Do NOT use `--first-frame` to chain scene N's last frame into scene N+1's generation — this produces a morphy, dissolve-y feel that reads as AI-generated.

**The only exception is a deliberate match-cut** — where the end of scene A and the start of scene B form an intentional visual rhyme (e.g. a ball rolling → a globe spinning). This is rare: 0-1 times per video, only when the user explicitly requests it. If you're unsure whether something qualifies as a match-cut, it doesn't — use a hard cut.

Identity consistency across hard cuts comes from **the same character specs and ref images being passed to every scene** — not from pixel handoff between frames. The `kling_generate` step appends character descriptions and `<<<image_N>>>` tokens to every prompt, so identity holds via the spec.

**Note:** Chained dispatch mode (documented above) remains available for the rare match-cut case. It is no longer the recommended default — use independent dispatch with hard cuts unless the user specifically requests visual continuity at a scene boundary.
```

**Step 2: Update the "What NOT to do" section**

Add:

```markdown
- **Don't chain scenes via `--first-frame` by default.** Hard cuts are the standard. Frame bridging produces morphy AI-slop transitions. Reserve `--first-frame` for deliberate match-cuts (rare, user-requested only).
```

**Step 3: Commit**

```bash
git add skills/ai-video/SKILL.md
git commit -m "docs: discourage smooth transitions, hard cuts by default in ai-video skill"
```

---

## Task 3: Richer Character Specs from Ref Images

**Files:**
- Modify: `skills/ai-video/SKILL.md` — Phase 1 anchor writing guidance

Note: The code change for appending specs to the composed prompt is already in Task 0 (`lib/ai_video.py`'s `compose_prompt` function). This task only updates the skill guidance for how the agent writes anchors.

**Step 1: Update Phase 1 anchor writing guidance**

In Phase 1's "Reference handling" section for `source: "upload"`, replace the current anchor guidance with:

```markdown
- Your job: write `anchor` — a **detailed character/object spec** (60-120 words). This is appended verbatim to every Kling prompt that references this character as a `[LABEL] spec` block in the CHARACTER/OBJECT SPECS section, so specificity matters. Cover:
  - **(a) Overall:** age range, gender, species/type, build, size
  - **(b) Distinguishing features:** face shape, eye color, fur/skin color, markings, expression style
  - **(c) Clothing/surface:** every visible garment or surface detail — color, fabric, fit, condition
  - **(d) Accessories:** any props, gear, distinctive marks
  - **(e) Art style cues:** outline weight, color fill style, proportions

  Example for a corgi character: "A small playful corgi with short legs, a long body, tan and golden fur with a white chest and belly, a fluffy white-tipped tail that curls upward, small pointed ears with tan fronts and white backs, round dark eyes with a friendly alert expression, a small black nose, bold black outlines with flat solid color fills, slightly exaggerated cartoon proportions with an oversized head relative to body."

- If you can't discern enough detail from the image, call `analyze_media --input <path> --prompt "Describe this character in 60-120 words covering: overall appearance, distinguishing features, colors, clothing/surface details, accessories, and art style. Be specific enough that a video generator could reproduce this character consistently across multiple scenes."` and use the output as the anchor.
```

**Step 2: Commit**

```bash
git add skills/ai-video/SKILL.md
git commit -m "docs: richer character spec guidance for Phase 1 anchor writing (60-120 words)"
```

---

## Task 4: `eval_scene` Step — Gemini Rubric + Retry Loop

This is the largest task. It creates a new step that evaluates a generated clip against a 5-dimension rubric using Gemini, and retries generation via the Kling connector if the clip fails.

**Files:**
- Create: `steps/eval_scene.py`
- Create: `steps/eval_scene.json`
- Modify: `workflows/ai_video.json` — add `eval_scene` step after `generate_scene`
- Modify: `ui/src/lib/types/schema.ts` — add `eval` field to generation type
- Test: `tests/test_eval_scene.py`

### Step 1: Create the step schema

Create `steps/eval_scene.json`:

```json
{
  "name": "eval_scene",
  "description": "Evaluate a generated scene clip against a 5-dimension quality rubric using Gemini. If the clip fails, regenerate via Kling up to max-retries times. Requires Gemini + Kling credentials.",
  "params": [
    {"name": "project-id", "type": "string", "required": true, "description": "Project ID"},
    {"name": "scene-id", "type": "string", "required": true, "description": "Scene ID to evaluate"},
    {"name": "max-retries", "type": "int", "required": false, "default": 2, "description": "Max regeneration attempts on failure (0 = evaluate only, no retry)"},
    {"name": "model", "type": "string", "required": false, "description": "Kling model for regeneration. Defaults to the model used for the original clip."},
    {"name": "eval-model", "type": "string", "required": false, "default": "gemini-2.5-flash", "description": "Gemini model for evaluation"},
    {"name": "negative-prompt", "type": "string", "required": false, "description": "Negative prompt for regeneration"},
    {"name": "mode", "type": "string", "required": false, "default": "std", "description": "std|pro for regeneration"}
  ]
}
```

### Step 2: Create the step script

Create `steps/eval_scene.py`:

```python
#!/usr/bin/env python3
"""Evaluate a generated scene clip and retry on failure.

Runs a 5-dimension Gemini critique on the clip. If it fails, regenerates
via Kling (non-deterministic re-roll with the same composed prompt) and
re-evaluates, up to max-retries times. Writes eval results to the
project's clip generation metadata.

Usage:
    eval_scene --project-id <id> --scene-id <scene-id> [--max-retries 2]
"""
import sys, os, argparse, json, time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "lib"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from common import fail, progress
from connectors import gemini, kling, ConnectorError
from lib.ai_video import (
    find_project, save_project, compose_prompt,
    resolve_ref_paths,
)


EVAL_RUBRIC = """You are evaluating a generated video clip for quality. The clip was generated from a text prompt using an AI video model.

Score each dimension 1-5 (1=terrible, 5=perfect). A clip PASSES only if ALL dimensions score >= 3.

## Dimensions

1. **CHARACTER_MATCH** — Do the characters match their descriptions? Check: correct colors, proportions, clothing, species/type, distinguishing features. Morphing or identity drift mid-clip is a fail.

2. **PHYSICS** — Is physics plausible? Check: gravity, shadows consistent with light source, reflections, momentum, scale relationships between objects. Floating objects, wrong shadows, or scale inconsistency is a fail.

3. **ANATOMY** — Are character bodies correct? Check: correct number of limbs/fingers, face stability, no body-part morphing. Extra fingers, melting faces, or limbs appearing/disappearing is a fail.

4. **ACTION** — Is the described action being performed? Check: the specific action in the prompt is visible and recognizable. A mimed action (hand near object but not touching) or wrong action is a fail.

5. **STANDALONE** — Is the shot readable in isolation? Check: subject is clear, action is clear, composition is legible. If a viewer can't tell what's happening without reading the prompt, it fails.

## Response format

Return ONLY valid JSON:
{{
  "pass": true or false,
  "scores": {{
    "character_match": N,
    "physics": N,
    "anatomy": N,
    "action": N,
    "standalone": N
  }},
  "suggestions": ["specific improvement suggestion 1", "..."]
}}

## Context

**Prompt used:** {prompt}

**Character specs:**
{specs}

Now evaluate the video clip."""


def _build_eval_prompt(composed_prompt: str, project: dict, scene: dict) -> str:
    """Build the Gemini evaluation prompt with character specs."""
    image_refs = {r["id"]: r for r in project.get("storyboard", {}).get("imageRefs", [])}
    specs = []
    for rid in scene.get("refImages", []):
        ref = image_refs.get(rid, {})
        label = ref.get("label", "")
        anchor = ref.get("anchor", "")
        if anchor:
            specs.append(f"[{label}] {anchor}")
    specs_text = "\n".join(specs) if specs else "(no character specs)"
    return EVAL_RUBRIC.format(prompt=composed_prompt, specs=specs_text)


def _evaluate_clip(clip_path: str, eval_prompt: str, eval_model: str) -> dict:
    """Run Gemini evaluation on a clip. Returns parsed verdict.

    Note: video files go through Gemini's Files API upload path (5-15s
    upload latency per clip). Budget this into wall-clock estimates.
    """
    try:
        raw = gemini.analyze_media(
            path=clip_path,
            prompt=eval_prompt,
            model=eval_model,
            json_output=True,
        )
    except ConnectorError as e:
        return {"pass": False, "scores": {}, "suggestions": [f"Eval failed: {e}"], "eval_error": str(e)}

    try:
        verdict = json.loads(raw)
    except json.JSONDecodeError:
        return {"pass": False, "scores": {}, "suggestions": ["Gemini returned non-JSON"], "raw": raw[:500]}

    return verdict


def main():
    p = argparse.ArgumentParser(description="Evaluate scene clip + retry on failure")
    p.add_argument("--project-id", dest="project_id", required=True)
    p.add_argument("--scene-id", dest="scene_id", required=True)
    p.add_argument("--max-retries", dest="max_retries", type=int, default=2)
    p.add_argument("--model", default=None,
                   help="Kling model for regeneration. Defaults to the model on the existing clip.")
    p.add_argument("--eval-model", dest="eval_model", default="gemini-2.5-flash")
    p.add_argument("--negative-prompt", dest="negative_prompt")
    p.add_argument("--mode", default="std", choices=["std", "pro"])
    args = p.parse_args()

    project_path, project = find_project(args.project_id)
    scenes = project.get("storyboard", {}).get("scenes", [])
    scene = next((s for s in scenes if s["id"] == args.scene_id), None)
    if not scene:
        fail("not_found", f"Scene {args.scene_id} not found")

    # Find existing clip for this scene
    tracks0 = project.get("tracks", [[]])[0]
    clip = next(
        (c for c in tracks0 if c.get("generation", {}).get("sceneId") == args.scene_id),
        None,
    )
    if not clip:
        fail("not_found", f"No clip found for scene {args.scene_id}. Generate first.")

    # Default model to whatever the clip was generated with
    kling_model = args.model or clip.get("generation", {}).get("model", "kling-v3-omni")

    # Re-compose prompt from scene data (not from stored generation.prompt,
    # which is the pre-composition natural-language version)
    composed_prompt = compose_prompt(project, scene)
    eval_prompt = _build_eval_prompt(composed_prompt, project, scene)

    attempt = 0
    while True:
        clip_path = clip["src"]
        progress(f"Evaluating {args.scene_id} (attempt {attempt + 1})...")

        verdict = _evaluate_clip(clip_path, eval_prompt, args.eval_model)
        progress(f"Eval result: pass={verdict.get('pass')} scores={verdict.get('scores', {})}")

        if verdict.get("pass") or attempt >= args.max_retries:
            # Save verdict to clip generation metadata
            _, project = find_project(args.project_id)
            tracks0 = project.get("tracks", [[]])[0]
            for c in tracks0:
                if c.get("generation", {}).get("sceneId") == args.scene_id:
                    c["generation"]["eval"] = {
                        "pass": verdict.get("pass", False),
                        "scores": verdict.get("scores", {}),
                        "attempt": attempt + 1,
                    }
            save_project(project_path, project)

            if verdict.get("pass"):
                progress(f"Scene {args.scene_id} PASSED evaluation")
            else:
                progress(f"Scene {args.scene_id} FAILED after {attempt + 1} attempts")

            print(json.dumps(verdict))
            return

        # Failed — regenerate (non-deterministic re-roll, same prompt)
        attempt += 1
        suggestions = verdict.get("suggestions", [])
        progress(f"Regenerating {args.scene_id} (attempt {attempt + 1}/{args.max_retries + 1}): {suggestions}")

        ref_paths = resolve_ref_paths(project, scene)
        duration = scene.get("duration", 5)
        sound = scene.get("sound", "on")
        aspect_ratio = project.get("storyboard", {}).get("aspectRatio", "16:9")
        task_id = f"{args.scene_id}-eval-{attempt}-{int(time.time())}"

        # Versioned output path — never overwrite previous attempts
        base = clip_path.rsplit(".mp4", 1)[0]
        out_path = f"{base}-v{attempt + 1}.mp4"

        # Push current clip to attempts history before regenerating
        _, project = find_project(args.project_id)
        tracks0 = project.get("tracks", [[]])[0]
        for c in tracks0:
            if c.get("generation", {}).get("sceneId") == args.scene_id:
                gen = c["generation"]
                gen.setdefault("attempts", []).append({
                    "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                    "prompt": gen.get("prompt", ""),
                    "src": c["src"],
                    "eval": verdict,
                })
                clip = c
                break
        save_project(project_path, project)

        try:
            new_path = kling.generate(
                prompt=composed_prompt,
                out_path=out_path,
                reference_image_paths=ref_paths or None,
                duration_seconds=duration,
                negative_prompt=args.negative_prompt,
                sound=sound,
                aspect_ratio=aspect_ratio,
                mode=args.mode,
                external_task_id=task_id,
                model=kling_model,
            )
        except ConnectorError as e:
            progress(f"Regeneration failed: {e}")
            _, project = find_project(args.project_id)
            for s in project.get("storyboard", {}).get("scenes", []):
                if s["id"] == args.scene_id:
                    s["lastError"] = {
                        "ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                        "message": f"Eval retry failed: {e}",
                    }
            save_project(project_path, project)
            fail("api_error", f"Eval retry {attempt} failed: {e}")

        progress(f"Regenerated {args.scene_id} -> {new_path}")

        # Update clip src to the new versioned path
        _, project = find_project(args.project_id)
        tracks0 = project.get("tracks", [[]])[0]
        for c in tracks0:
            if c.get("generation", {}).get("sceneId") == args.scene_id:
                c["src"] = new_path
                clip = c
                break
        save_project(project_path, project)


if __name__ == "__main__":
    main()
```

### Step 3: Add to workflow

Modify `workflows/ai_video.json` — add after `generate_scene`:

```json
{
  "id": "eval_scene",
  "uses": "montaj/eval_scene",
  "foreach": "storyboard.scenes",
  "needs": ["generate_scene"],
  "description": "Per scene (post-generation): Gemini evaluates the clip against a 5-dimension quality rubric. If it fails, regenerates via Kling up to max-retries times. The workflow JSON is declarative intent — the agent drives execution via SKILL.md Phase 6 Step F guidance."
}
```

### Step 4: Update TypeScript types

In `ui/src/lib/types/schema.ts`, add `eval` to the generation block type:

```typescript
eval?: {
  pass: boolean
  scores: Record<string, number>
  attempt: number
}
```

### Step 5: Write tests

Create `tests/test_eval_scene.py`:

```python
"""Tests for eval_scene step — rubric construction and verdict parsing."""
import json
import pytest

from steps.eval_scene import _build_eval_prompt, _evaluate_clip


def test_build_eval_prompt_includes_character_specs():
    project = {
        "storyboard": {
            "imageRefs": [
                {"id": "ref1", "label": "Max the Dog", "refImages": ["/fake.png"],
                 "anchor": "A golden retriever with floppy ears and a red collar."},
            ],
        }
    }
    scene = {"id": "s1", "prompt": "Max runs", "refImages": ["ref1"]}
    result = _build_eval_prompt("full prompt here", project, scene)
    assert "[Max the Dog]" in result
    assert "golden retriever" in result
    assert "full prompt here" in result


def test_build_eval_prompt_no_specs():
    project = {"storyboard": {"imageRefs": []}}
    scene = {"id": "s1", "prompt": "test", "refImages": []}
    result = _build_eval_prompt("prompt", project, scene)
    assert "(no character specs)" in result


def test_build_eval_prompt_has_all_dimensions():
    project = {"storyboard": {"imageRefs": []}}
    scene = {"id": "s1", "prompt": "test", "refImages": []}
    result = _build_eval_prompt("prompt", project, scene)
    for dim in ["CHARACTER_MATCH", "PHYSICS", "ANATOMY", "ACTION", "STANDALONE"]:
        assert dim in result
```

Note: `_evaluate_clip` calls `gemini.analyze_media` which requires network — don't unit-test it directly. Integration tests can cover it separately.

### Step 6: Run tests

```bash
pytest tests/test_eval_scene.py tests/test_ai_video_lib.py -v
```

### Step 7: Commit

```bash
git add steps/eval_scene.py steps/eval_scene.json workflows/ai_video.json ui/src/lib/types/schema.ts tests/test_eval_scene.py
git commit -m "feat: eval_scene step — Gemini rubric + Kling retry loop for ai_video quality"
```

---

## Task 5: Update AI-Video Skill for Eval Loop

**Files:**
- Modify: `skills/ai-video/SKILL.md` — Phase 6

**Step 1: Add eval guidance after Phase 6 Step E (wrap up)**

Add a new section:

```markdown
### Step F — evaluate generated clips (optional but recommended)

After all scenes have clips, run the eval loop:

    for each scene:
      eval_scene --project-id {id} --scene-id {scene.id} --max-retries 2

The step evaluates each clip against a 5-dimension quality rubric (character match, physics, anatomy, action, standalone) using Gemini. If a clip fails, the step regenerates it via Kling (non-deterministic re-roll with the same composed prompt) and re-evaluates, up to `max-retries` times. Previous attempts are preserved as versioned files (`scene-1-v2.mp4`, etc.) and recorded in `generation.attempts[]` with their eval verdicts.

Results are stored on `tracks[0][i].generation.eval` — `{pass, scores, attempt}`.

**When to skip:** If the user says they're happy with the clips, want to iterate manually, or are cost-sensitive (each eval = 1 Gemini call + potentially N Kling calls per scene).

**Note:** The eval loop does NOT revise prompts — it re-rolls generation with the same prompt, relying on Kling's non-determinism to produce a better draw. Prompt revision based on Gemini feedback is a future enhancement.
```

**Step 2: Commit**

```bash
git add skills/ai-video/SKILL.md
git commit -m "docs: add eval loop guidance (Step F) to ai-video skill Phase 6"
```

---

## Summary

| Task | What | Files | Test |
|------|------|-------|------|
| 0 | Extract shared helpers to `lib/ai_video.py` | `lib/ai_video.py`, `steps/kling_generate.py` | `tests/test_ai_video_lib.py` |
| 1 | Camera vocabulary sub-skill + TypeScript types | `skills/camera-vocabulary/SKILL.md`, `skills/ai-video/SKILL.md`, `ui/src/lib/types/schema.ts` | Manual |
| 2 | Discourage smooth transitions | `skills/ai-video/SKILL.md` | Manual |
| 3 | Richer character specs guidance | `skills/ai-video/SKILL.md` | Manual |
| 4 | `eval_scene` step + TypeScript types | `steps/eval_scene.py`, `steps/eval_scene.json`, `workflows/ai_video.json`, `ui/src/lib/types/schema.ts` | `tests/test_eval_scene.py` |
| 5 | Skill docs for eval loop | `skills/ai-video/SKILL.md` | Manual |

Total: ~6 commits, 5 new files, 5 modified files, 2 test files.

Key fixes from review:
- **Blocker 1:** Shared helpers extracted to `lib/ai_video.py` (Task 0) — no cross-step imports.
- **Blocker 2:** Eval retry re-composes prompt from scene data via `compose_prompt()`, not from stored `generation.prompt`.
- **Blocker 3:** Versioned output paths (`scene-1-v2.mp4`) — never overwrite previous attempts.
- **Issue 5:** Prompt structure explicitly documented; camera tags come before specs section.
- **Issue 6:** `shotScale`/`cameraMove` added to TypeScript Scene type.
- **Issue 7:** `eval` added to TypeScript generation type.
- **Issue 8:** Sub-skills table referenced by content, not line number.
- **Issue 9:** Kling model defaults to `clip["generation"]["model"]`, CLI arg is override.
- **Issue 10:** Fenced code block nesting fixed.
- **Design:** Workflow JSON addition noted as declarative intent; SKILL.md drives execution. Chained mode reconciled with hard-cuts guidance. No-prompt-revision noted as deliberate v1 scope with future path.
