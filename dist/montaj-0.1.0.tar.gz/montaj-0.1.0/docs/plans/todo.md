# Montaj To Do

---
- [ ] Test editing on Claude Desktop via mcp server
- [ ] Add pure audio support
- [ ] Build a landing page for montaj

- [ ] Allow speeding up speech
- [ ] Adaptors — external AI API harnesses (Stitch/Veo/ElevenLabs/Runway/Suno). Design contract, CLI interface, credential resolution, server routes.
- [ ] Background removal: convert RVM to CoreML (.mlpackage) and run via coremltools on Apple Neural Engine — would match CapCut speed (Neural Engine >> MPS for this class of model). Do it if faster performance is needed.

- [ ] **Generalize `foreach` beyond `"clips"`.** Today `docs/schemas/workflow.md` pins `foreach: "clips"` — it fans a step out across all project clips. For AI-video workflows we need `foreach: "scenes"`, `foreach: "characters"`, `foreach: "environments"` driven by agent-authored arrays in `project.json`. Small engine extension: make `foreach` reference any named array on the project, not just `clips`.

- [ ] **Cross-`foreach` dependencies in the workflow engine.** AI-video workflows need character refs (from a `foreach: "characters"` fan-out) to be passed as `--ref-image` into the corresponding scene's `kling_generate` (a `foreach: "scenes"` fan-out). The current `needs:` dependency model only expresses "step B runs after step A completes for all items" — not "scene-N in step B uses the output of character-K in step A." Needs a per-item dependency expression (e.g. a templated param that resolves against the scene's own fields: `--ref-image {{scene.characterRefs[].path}}`).


### Nice-to-have before public

- [ ] **GitHub Actions CI** — `.github/workflows/test.yml` that runs `make test` on push. Gives contributors confidence. Basic matrix: Python 3.10, 3.12.
- [ ] **Issue templates** — `.github/ISSUE_TEMPLATE/bug_report.md` and `feature_request.md`. Keeps issues useful.
- [ ] **PyPI publish** — Planned. README currently shows install from source. When ready: `python -m build && twine upload dist/*`, then update README to `pip install montaj`.
above.


## DONZO
- [x] Remove unused steps (i.e ffmpeg captions) for final cleanup
- [x] Ripple mode for primary track edits — right-edge drag and cuts on tracks[0] should shift all subsequent clips left to close the gap. Currently lift-style (gap left in place). Ripple is the right default for talking-head primary tracks.
- [x] Add workflows for transparent background/talking head — `floating_head.json` added. UI input differentiation deferred (handled at prompt level for now).
- [x] Timeline cuts should be a timeline-level operation affecting all tracks — `applyCutToTracks` (lift-style, all tracks[0] clips) and `applyCutToItem` (collapse-style, single selected item in any track). Selection-aware dispatch in ReviewView. All pure JSON, no re-encode.
- [x] Add support for multi video tracks — addressed by unified `tracks` array (tracks[0] = primary footage, tracks[1+] = overlays; each inner array is one z-level; items can mix overlay/image/video types)
- [x] No need for final concat. Support individual clips in video track — `concat` replaced by trim-spec architecture; compose.js assembles from tracks[0] clips natively
